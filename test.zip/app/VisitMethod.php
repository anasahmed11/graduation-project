<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VisitMethod extends Model
{
    public $timestamps = false;
}

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
        <div class="col-md-12 c_text login_page col-md-4 wow fadeInRight"data-wow-duration="2s" data-wow-offset="300">
            <table class="table table-responsive table-striped">
                <thead>
                <tr>
                    <th>id</th>
                    <th>type</th>
                    <th>update</th>
                    <th>delete</th>
                </tr>
                </thead>
                <tbody>

                <?php $__currentLoopData = $methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <td><?php echo e($method->id); ?> </td>
                        <td><?php echo e($method->method); ?></td>
                        <td><button class="btn btn-success edit" data-toggle="modal" data-target="#exampleModalCenter" >update</button></td>
                        <td><?php echo e(Form::open(['action' => ['PaymentMethodsController@destroy',$method->id]])); ?>

                            <?php echo e(method_field('DELETE')); ?>

                            <?php echo e(Form::submit('Delete',['class' => 'btn btn-danger '])); ?>

                            <?php echo e(Form::close()); ?></td>
                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                </tbody>
            </table>

        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <button class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter-new">Add new</button>
        </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="exampleModalCenter-new" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">update item</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">x</span>
                    </button>
                </div>
                <div class="modal-body">
                    <?php echo e(Form::open(['action' => ['PaymentMethodsController@store']])); ?>

                    <?php echo e(Form::label('method', 'method')); ?>

                    <?php echo e(Form::text('method','',['class' => 'form-control'])); ?><br>
                    <?php echo e(Form::submit('save changes',['class' => 'btn btn-primary btn-lg btn-block'])); ?>


                    <?php echo e(Form::close()); ?>


                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_dash', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12 c_text login_page col-md-4 wow fadeInRight"data-wow-duration="2s" data-wow-offset="300">
            <table class="method-table table table-responsive table-striped ">
                <thead>
                <tr>
                    <th>id</th>
                    <th>title</th>
                    <th>article</th>
                    <th>photo</th>
                    <th>update</th>
                    <th>delete</th>
                </tr>
                </thead>
                <tbody>

                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr class="blog-<?php echo e($blog->id); ?>">
                        <td><?php echo e($blog->id); ?> </td>
                        <td><?php echo e($blog->title); ?></td>
                        <td><?php echo e($blog->article); ?></td>
                        <td><img src="<?php echo e(url("/uploads/$blog->photo")); ?>" width="100px" ></td>
                        <td><button class="edit-blog btn btn-success"  data-toggle="modal" data-target="#edit-modal-method" data-id="<?php echo e($blog->id); ?>" data-title="<?php echo e($blog->title); ?>" data-article="<?php echo e($blog->article); ?>" data-photo="<?php echo e($blog->photo); ?>" >update</button></td>
                        <td><button class="delete-blog btn btn-danger" data-id="<?php echo e($blog->id); ?>">delete</button></td>
                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                </tbody>
            </table>

        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <button class="btn btn-primary"  data-toggle="modal" data-target="#exampleModalCenter-new">Add new</button>
        </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="exampleModalCenter-new" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">new method</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">x</span>
                    </button>
                </div>
                <div class="modal-body">
                    <?php echo e(Form::open(array('id'=>'add-blog-form','enctype'=>'multipart/form-data'))); ?>

                    <?php echo e(Form::label('title', 'title')); ?>

                    <?php echo e(Form::text('title','',['class' => 'form-control'])); ?><br>
                    <?php echo e(Form::label('article', 'article')); ?>

                    <?php echo e(Form::textarea('article','',['class' => 'form-control','rows' =>3,'cols'=>10,'placeholder'=>'Write article'])); ?><br>
                    <?php echo e(Form::label('photo', 'photo')); ?>

                    <?php echo e(Form::file('photo',['id'=>'photo-new'])); ?><br><br>
                    <?php echo e(Form::submit('save changes',['class' => 'btn btn-primary btn-lg btn-block','id'=>'new-blog'])); ?>

                    <?php echo e(Form::close()); ?>

                    <br>
                    <div class="met alert alert-success">

                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="edit-modal-method" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">update item</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">x</span>
                    </button>
                </div>
                <div class="modal-body">
                    <?php echo e(Form::open(array('id'=>'edit-blog-form','enctype'=>'multipart/form-data'))); ?>

                    <?php echo e(Form::label('title', 'title')); ?>

                    <?php echo e(Form::text('title','',['class' => 'form-control','id'=>'title-edit'])); ?><br>
                    <?php echo e(Form::label('article', 'article')); ?>

                    <?php echo e(Form::textarea('article','',['class' => 'form-control','rows' =>3,'cols'=>10,'placeholder'=>'Write article','id'=>'article-edit'])); ?><br>
                    <?php echo e(Form::label('photo', 'photo')); ?>

                    <?php echo e(Form::file('photo',['class' => 'btn btn-dark'])); ?><br><br>
                    <?php echo e(Form::submit('save changes',['class' => 'btn btn-primary btn-lg btn-block','id'=>'edit-blog'])); ?>

                    <?php echo e(Form::close()); ?>

                    <br>
                    <div class="met alert alert-success">

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin_dash', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
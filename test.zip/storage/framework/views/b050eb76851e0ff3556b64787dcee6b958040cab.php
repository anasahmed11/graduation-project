<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12 c_text login_page col-md-4 wow fadeInRight"data-wow-duration="2s" data-wow-offset="300">
            <table class="method-table table table-responsive table-striped ">
                <thead>
                <tr>
                    <th>id</th>
                    <th>name</th>
                    <th>update</th>
                    <th>delete</th>
                </tr>
                </thead>
                <tbody>

                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr class="category-<?php echo e($category->id); ?>">
                        <td><?php echo e($category->id); ?> </td>
                        <td><?php echo e($category->name); ?></td>
                        <td><button class="edit-category btn btn-success"  data-toggle="modal" data-target="#edit-modal-method" data-id="<?php echo e($category->id); ?>" data-title="<?php echo e($category->name); ?>" >update</button></td>
                        <td><button class="delete-category btn btn-danger" data-id="<?php echo e($category->id); ?>">delete</button></td>
                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                </tbody>
            </table>

        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <button class="btn btn-primary"  data-toggle="modal" data-target="#exampleModalCenter-new">Add new</button>
        </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="exampleModalCenter-new" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">new method</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">x</span>
                    </button>
                </div>
                <div class="modal-body">
                    <?php echo e(Form::open(array('id'=>'add-category-form'))); ?>

                    <?php echo e(Form::label('name', 'name')); ?>

                    <?php echo e(Form::text('name','',['class' => 'form-control'])); ?><br>
                    <?php echo e(Form::submit('save changes',['class' => 'btn btn-primary btn-lg btn-block','id'=>'new-category'])); ?>

                    <?php echo e(Form::close()); ?>

                    <br>
                    <div class="cat alert alert-success">

                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="edit-modal-method" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">update item</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">x</span>
                    </button>
                </div>
                <div class="modal-body">
                    <?php echo e(Form::open(array('id'=>'edit-category-form'))); ?>

                    <?php echo e(method_field('PUT')); ?>

                    <?php echo e(Form::label('name', 'name')); ?>

                    <?php echo e(Form::text('name', '' ,['class' => 'form-control','id' => 'category-edit'])); ?><br>
                    <?php echo e(Form::submit('save changes',['class' => 'btn btn-primary btn-lg btn-block','id'=>'edit-category'])); ?>

                    <?php echo e(Form::close()); ?>

                    <br>
                    <div class="cat alert alert-success">

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin_dash', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
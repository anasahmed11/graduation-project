<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <div class="blog-nav">
                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <button class="btn btn-block  blog-ajx
                            <?php if($blog->id%4 === 0&&$blog->id%2 === 0): ?>
                                <?php echo e("btn-4"); ?>

                            <?php elseif($blog->id%2 === 0): ?>
                                <?php echo e("btn-2"); ?>

                             <?php elseif($blog->id%3 === 0): ?>
                                 <?php echo e("btn-3"); ?>

                            <?php elseif($blog->id === 7): ?>
                                <?php echo e("btn-3"); ?>

                            <?php else: ?>
                                <?php echo e("btn-1"); ?>

                            <?php endif; ?>
                         " data-title="<?php echo e($blog->title); ?>" data-article="<?php echo e($blog->article); ?>" data-photo="<?php echo e($blog->photo); ?>"><?php echo e($blog->title); ?></button><br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="col-md-7 offset-1 wow fadeInDown"data-wow-duration="2s" data-wow-offset="300">
                <div class="blog">
                <div class="home-img img-ajx">
                    <img src="<?php echo e(url('/uploads/1554503255.jpeg')); ?>"  width="100%" class="img-responsive" alt="html5 bootstrap template">
                </div>
                <div class="h-desc desc desc-ajx wow fadeInUp"data-wow-duration="2s" data-wow-offset="300">
                    <h2>click on any button</h2><br>
                    <p>
                        # it is very important to read this topics to gather primary information about what you suffer from<br><br>
                        # select any field to read some of articles about the field you choose<br><br>
                        # we provide some of topics written by experts in psychology , this topics help you to know what do you need from your doctor
                        <br><br>

                    </p>
                </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.myapp', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
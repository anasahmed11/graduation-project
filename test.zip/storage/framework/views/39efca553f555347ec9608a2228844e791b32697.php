<?php $__env->startSection('content'); ?>
    <div class="container">
            <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(Auth::user()->id == $doctor->u_id ): ?>
                    <div class="row">
                        <div class="col-md-4 offset-4 profile-img">
                            <img class="wow fadeInDown" data-wow-duration="2s" data-wow-offset="300" src="<?php echo e(url("/uploads/$doctor->photo")); ?>" width="150px" ><br>
                            <h2 class="wow fadeInUp" data-wow-duration="2s" data-wow-offset="300"><?php echo e($doctor->name); ?></h2>
                            <?php $__currentLoopData = $rates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(Auth::user()->id == $rate->d_id ): ?>
                                    <?php if($rate->rate <=5 ): ?>
                                        <span class=" wow flash"data-wow-duration="2s" data-wow-offset="300">
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star-half"></i>
                                            <br>
                                        </span>
                                     <?php else: ?>
                                        <span class=" wow flash"data-wow-duration="2s" data-wow-offset="300">
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star-half"></i>
                                            <br>
                                        </span>
                                     <?php endif; ?>
                                <?php endif; ?>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4 profile-info wow fadeInLeft"data-wow-duration="2s" data-wow-offset="300" >
                            <p class="certificate"><i class="fas fa-graduation-cap"></i>Certificates : </p>
                            <p class="certificate-desc"><?php echo e($doctor->Certificates); ?></p>
                        </div>
                        <div class="col-md-4 profile-mail wow fadeInDown"data-wow-duration="2.3s" data-wow-offset="300" >
                            <p class="p-email"><span class="certificate">Email : </span><i class="fas fa-address-card"></i><?php echo e($doctor->email); ?></p>
                            <p class="p-address"><span class="certificate">city : </span><i class="fas fa-map-marker-alt"></i><?php echo e($doctor->address); ?></p>
                        </div>
                        <div class="col-md-4 profile-prices wow fadeInRight"data-wow-duration="2.6s" data-wow-offset="300">
                            <?php $__currentLoopData = $methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(Auth::user()->id == $price->d_id): ?>
                                        <?php if($method->id==$price->type_id): ?>
                                            <p class="p-price"><span class="certificate"><?php echo e($method->type); ?> : </span><?php if($method->id===1): ?><i class="fas fa-clinic-medical"></i><?php else: ?><i class="fas fa-video"></i><?php endif; ?><?php echo e($price->price); ?> EGP</p>

                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="container">
                    <div class="row">
                        <div class="col-md-6">
                            <button class="set-price1 btn btn-block btn-primary"  data-toggle="modal" data-target="#set-modal-1" data-id="<?php echo e($doctor->u_id); ?>"  >Set Ordinary visit price</button><br>
                        </div>
                        <div class="col-md-6">
                            <button class="set-price2 btn btn-block btn-primary"  data-toggle="modal" data-target="#set-modal-2" data-id="<?php echo e($doctor->u_id); ?>"  >Set Video chat price</button><br>
                        </div>
                    </div>
                    </div>
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($location->d_id == Auth::user()->id): ?>
                                        <div id="map" data-id="<?php echo e($location->d_id); ?>" data-name="<?php echo e($location->name); ?>" data-long="<?php echo e($location->long); ?>" data-lat="<?php echo e($location->lat); ?>"></div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>

                    <div class="container">
                    <div class="row">
                        <div class="col-md-6 offset-3">
                            <button class="edit-doctor btn btn-block btn-success"  data-toggle="modal" data-target="#edit-modal-doc" data-id="<?php echo e($doctor->u_id); ?>" data-name="<?php echo e($doctor->name); ?>" data-email="<?php echo e($doctor->email); ?>" data-photo="<?php echo e($doctor->photo); ?>" data-cert="<?php echo e($doctor->Certificates); ?>" data-address="<?php echo e($doctor->address); ?>">Edit Profile</button>
                        </div>
                    </div>
                    </div>

                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="edit-modal-doc" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">update profile</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">x</span>
                    </button>
                </div>
                <div class="modal-body">
                    <?php echo e(Form::open(array('id'=>'edit-doctor-form','enctype'=>'multipart/form-data'))); ?>

                    <?php echo e(Form::label('name', 'name')); ?>

                    <?php echo e(Form::text('name','',['class' => 'form-control','id'=>'doc-name-edit'])); ?><br>
                    <?php echo e(Form::label('email', 'email')); ?>

                    <?php echo e(Form::email('email','',['class' => 'form-control','placeholder'=>'Email','id'=>'doc-email-edit'])); ?><br>
                    <?php echo e(Form::password('password',['class' => 'form-control','placeholder'=>'password'])); ?><br>
                    <?php echo e(Form::password('password_confirmation',['class' => 'form-control','placeholder'=>'password','id' => 'password-confirm'])); ?><br>
                    <?php echo e(Form::label('city', 'city')); ?>

                    <?php echo e(Form::text('address','',['class' => 'form-control','id'=>'address-edit'])); ?><br>
                    <?php echo e(Form::textarea('certificates','',['class' => 'form-control','rows' =>3,'cols'=>10,'placeholder'=>'Write certificates','id'=>'certificates-edit'])); ?><br><br>
                    <?php echo e(Form::label('photo', 'photo')); ?>

                    <?php echo e(Form::file('photo',['id'=>'photo-doc-edit'])); ?><br><br>
                    <?php echo e(Form::submit('save changes',['class' => 'btn btn-primary btn-lg btn-block','id'=>'new-doctor-edit'])); ?>

                    <?php echo e(Form::close()); ?>

                    <br>
                    <div class="met alert alert-success">

                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- price 1 Modal -->
    <div class="modal fade" id="set-modal-1" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">update profile</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">x</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="col-md-12">
                        <p class="price-hint">
                            please set your prices for first time only <br>
                            if you want to change your  prices make a <br>
                            request to the admin
                        </p>
                    </div>
                    <?php echo e(Form::open(array('id'=>'set-price1-form'))); ?>

                    <?php echo e(Form::label('Ordinary visit', 'Ordinary visit')); ?>

                    <?php echo e(Form::number('price','',['class' => 'form-control'])); ?><br>
                    <?php echo e(Form::submit('save changes',['class' => 'btn btn-primary btn-lg btn-block','id'=>'set-price1'])); ?>

                    <?php echo e(Form::close()); ?>

                    <br>
                    <div class="met alert alert-success">

                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- price 2 Modal -->
    <div class="modal fade" id="set-modal-2" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">update profile</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">x</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="col-md-12">
                        <p class="price-hint">
                            please set your prices for first time only <br>
                            if you want to change your  prices make a <br>
                            request to the admin
                        </p>
                    </div>
                    <?php echo e(Form::open(array('id'=>'set-price2-form'))); ?>

                    <?php echo e(Form::label('Video Chat', 'Video Chat')); ?>

                    <?php echo e(Form::number('price','',['class' => 'form-control'])); ?><br>
                    <?php echo e(Form::submit('save changes',['class' => 'btn btn-primary btn-lg btn-block','id'=>'set-price2'])); ?>

                    <?php echo e(Form::close()); ?>

                    <br>
                    <div class="met alert alert-success">

                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- price 1 edit  Modal -->
    <div class="modal fade" id="edit-modal-1" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">update profile</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">x</span>
                    </button>
                </div>
                <div class="modal-body">
                    <?php echo e(Form::open(array('id'=>'edit-price1-form'))); ?>

                    <?php echo e(Form::label('Ordinary visit', 'Ordinary visit')); ?>

                    <?php echo e(Form::number('price','',['class' => 'form-control'])); ?><br>
                    <?php echo e(Form::submit('save changes',['class' => 'btn btn-primary btn-lg btn-block','id'=>'edit-price1'])); ?>

                    <?php echo e(Form::close()); ?>

                    <br>
                    <div class="met alert alert-success">

                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- price 2 edit Modal -->
    <div class="modal fade" id="edit-modal-2" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">update profile</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">x</span>
                    </button>
                </div>
                <div class="modal-body">
                    <?php echo e(Form::open(array('id'=>'edit-price2-form'))); ?>

                    <?php echo e(Form::label('Video Chat', 'Video Chat')); ?>

                    <?php echo e(Form::number('price','',['class' => 'form-control'])); ?><br>
                    <?php echo e(Form::submit('save changes',['class' => 'btn btn-primary btn-lg btn-block','id'=>'edit-price2'])); ?>

                    <?php echo e(Form::close()); ?>

                    <br>
                    <div class="met alert alert-success">

                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.doctor_dash', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
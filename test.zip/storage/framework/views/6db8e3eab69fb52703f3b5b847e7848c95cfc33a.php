<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12 c_text login_page col-md-4 wow fadeInRight"data-wow-duration="2s" data-wow-offset="300">
            <table class="method-table table table-responsive table-striped ">
                <thead>
                <tr>
                    <th>id</th>
                    <th>name</th>
                    <th>email</th>
                    <th>phone</th>
                    <th>certificates</th>
                    <th>age</th>
                    <th>experience</th>
                    <th>delete</th>
                </tr>
                </thead>
                <tbody>

                <?php $__currentLoopData = $doctor_r; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr class="doctorreq-<?php echo e($doctor->id); ?>">
                        <td><?php echo e($doctor->id); ?> </td>
                        <td><?php echo e($doctor->name); ?></td>
                        <td><?php echo e($doctor->email); ?></td>
                        <td><?php echo e($doctor->phone); ?></td>
                        <td><?php echo e($doctor->certificates); ?></td>
                        <td><?php echo e($doctor->age); ?></td>
                        <td><?php echo e($doctor->experience); ?></td>
                        <td><button class="delete-doctorreq btn btn-danger" data-id="<?php echo e($doctor->id); ?>">delete</button></td>
                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin_dash', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div id="multi-map" ></div>
    </div>
</div>
<script type="text/javascript">
    var locations=[];
        <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        locations.push(["<?php echo e($location->name); ?>",parseFloat(<?php echo e($location->lat); ?>),parseFloat(<?php echo e($location->long); ?>),<?php echo e($location->d_id); ?>]);
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    var map = new google.maps.Map(document.getElementById('multi-map'), {
        zoom: 7,
        center: new google.maps.LatLng(31.0409, 31.3785),
        mapTypeId: google.maps.MapTypeId.ROADMAP
    });

    var infowindow = new google.maps.InfoWindow();

    var marker, i;

    for (i = 0; i < locations.length; i++) {
        marker = new google.maps.Marker({
            position: new google.maps.LatLng(locations[i][1], locations[i][2]),
            map: map
        });

        google.maps.event.addListener(marker, 'click', (function(marker, i) {
            return function() {
                infowindow.setContent(locations[i][0]);
                infowindow.open(map, marker);
            }
        })(marker, i));
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.patient_dash', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
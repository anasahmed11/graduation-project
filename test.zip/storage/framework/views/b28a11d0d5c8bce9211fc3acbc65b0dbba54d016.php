<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12 c_text login_page col-md-4 wow fadeInRight"data-wow-duration="2s" data-wow-offset="300">
            <table class="method-table table table-responsive table-striped ">
                <thead>
                <tr>
                    <th>id</th>
                    <th>name</th>
                    <th>email</th>
                    <th>review</th>
                    <th>created_at</th>
                </tr>
                </thead>
                <tbody>

                <?php $__currentLoopData = $client_r; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr >
                        <td><?php echo e($client->id); ?> </td>
                        <td><?php echo e($client->name); ?></td>
                        <td><?php echo e($client->email); ?></td>
                        <td><?php echo e($client->review); ?></td>
                        <td><?php echo e($client->created_at); ?></td>
                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin_dash', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
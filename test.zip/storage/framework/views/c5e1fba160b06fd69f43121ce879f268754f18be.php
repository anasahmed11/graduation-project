<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12 c_text login_page col-md-4 wow fadeInRight"data-wow-duration="2s" data-wow-offset="300">
            <table class="method-table table table-responsive table-striped ">
                <thead>
                <tr>
                    <th>id</th>
                    <th>name</th>
                    <th>long</th>
                    <th>lat</th>
                    <th>doctor_id</th>
                    <th>update</th>
                    <th>delete</th>
                </tr>
                </thead>
                <tbody>

                <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr class="location-<?php echo e($location->id); ?>">
                        <td><?php echo e($location->id); ?> </td>
                        <td><?php echo e($location->name); ?></td>
                        <td><?php echo e($location->long); ?></td>
                        <td><?php echo e($location->lat); ?></td>
                        <td><?php echo e($location->d_id); ?></td>
                        <td><button class="edit-location btn btn-success"  data-toggle="modal" data-target="#edit-modal-location" data-id="<?php echo e($location->id); ?>" data-name="<?php echo e($location->name); ?>" data-long="<?php echo e($location->long); ?>" data-lat="<?php echo e($location->lat); ?>" data-doctor="<?php echo e($location->d_id); ?>">update</button></td>
                        <td><button class="delete-location btn btn-danger" data-id="<?php echo e($location->id); ?>">delete</button></td>
                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                </tbody>
            </table>

        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <button class="btn btn-primary"  data-toggle="modal" data-target="#exampleModalCenter-new">Add new</button>
        </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="exampleModalCenter-new" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">new method</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">x</span>
                    </button>
                </div>
                <div class="modal-body">
                    <?php echo e(Form::open(array('id'=>'add-location-form'))); ?>

                    <?php echo e(Form::label('name', 'name')); ?>

                    <?php echo e(Form::text('name','',['class' => 'form-control'])); ?><br>
                    <?php echo e(Form::label('long', 'long')); ?>

                    <?php echo e(Form::number('long','',['class' => 'form-control','step'=>'0.0000000001'])); ?><br>
                    <?php echo e(Form::label('lat', 'lat')); ?>

                    <?php echo e(Form::number('lat','',['class' => 'form-control','step'=>'0.0000000001'])); ?><br>
                    <?php echo e(Form::label('doctor_id', 'doctor_id')); ?>

                    <?php echo e(Form::number('d_id','',['class' => 'form-control'])); ?><br><br>
                    <?php echo e(Form::submit('save changes',['class' => 'btn btn-primary btn-lg btn-block','id'=>'new-location'])); ?>

                    <?php echo e(Form::close()); ?>

                    <br>
                    <div class="met alert alert-success">

                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="edit-modal-location" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">update item</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">x</span>
                    </button>
                </div>
                <div class="modal-body">
                    <?php echo e(Form::open(array('id'=>'edit-location-form'))); ?>

                    <?php echo e(Form::label('name', 'name')); ?>

                    <?php echo e(Form::text('name','',['class' => 'form-control','id'=>'name-edit'])); ?><br>
                    <?php echo e(Form::label('long', 'long')); ?>

                    <?php echo e(Form::number('long','',['class' => 'form-control','id'=>'long-edit','step'=>'0.0000000001'])); ?><br>
                    <?php echo e(Form::label('lat', 'lat')); ?>

                    <?php echo e(Form::number('lat','',['class' => 'form-control','id'=>'lat-edit','step'=>'0.0000000001'])); ?><br>
                    <?php echo e(Form::label('doctor_id', 'doctor_id')); ?>

                    <?php echo e(Form::number('d_id','',['class' => 'form-control','id'=>'d_id-edit'])); ?><br><br>
                    <?php echo e(Form::submit('save changes',['class' => 'btn btn-primary btn-lg btn-block','id'=>'edit-location'])); ?>

                    <?php echo e(Form::close()); ?>

                    <br>
                    <div class="met alert alert-success">

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin_dash', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>